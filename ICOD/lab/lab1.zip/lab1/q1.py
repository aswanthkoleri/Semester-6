class DFA:
    def __init__(self, nstates):
        self.transitions = [{} for i in range(nstates)]
        self.accept_states = [False] * nstates

    def register(self, source_state, char, target_state):
        self.transitions[source_state][char] = target_state

    def register_accept(self, state):
        # print(self.accept_states)
        # print(state)
        self.accept_states[state] = True

    def accept(self, input):
        state = 0
        try:
            for char in input:
                state = self.transitions[state][char]
            return self.accept_states[state]
        except KeyError:
            return False
          
# These are the defined keywords
keywords=["if ","while ","then ","do ","for ","else ","goto ","break ","malloc","return "]

def detect(texts):
    global keywords
    for text in texts:
        for key in keywords:
            dfa= DFA(len(key))
            i=0
            for k in key:
                dfa.register(i,k,i+1)
                i=i+1
            dfa.register_accept(len(key)-1)
            if dfa.accept(text):
                print("Keyword detected : " + text)

def main():
    print("Enter your text : ")
    texts=input().split(" ")
    detect(texts)

main()


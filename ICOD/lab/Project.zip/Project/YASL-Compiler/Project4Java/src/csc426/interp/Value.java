package csc426.interp;

public abstract class Value {
	
	public abstract int intValue();
	public abstract boolean boolValue();
	
}

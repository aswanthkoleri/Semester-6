package csc426.ast;

public enum Op1 {
	Neg, 
	Not
}

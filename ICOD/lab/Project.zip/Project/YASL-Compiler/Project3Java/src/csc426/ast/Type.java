package csc426.ast;

public enum Type {
	Int, 
	Bool, 
	Void
}

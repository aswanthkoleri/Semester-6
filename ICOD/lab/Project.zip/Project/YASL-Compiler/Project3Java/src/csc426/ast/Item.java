package csc426.ast;

public abstract class Item extends ASTNode {
	
}

package csc426.ast;

public abstract class Stmt extends ASTNode {

}

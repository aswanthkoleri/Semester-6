package csc426.ast;

public abstract class ASTNode {
	public abstract void display(String indentation);
}

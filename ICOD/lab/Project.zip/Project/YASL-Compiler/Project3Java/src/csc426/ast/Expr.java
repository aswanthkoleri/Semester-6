package csc426.ast;

public abstract class Expr extends ASTNode {
}

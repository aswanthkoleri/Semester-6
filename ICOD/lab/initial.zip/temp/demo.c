#include<stdio.h>
#include "basic.h"

int main()
{
	printf("add is %d",add(5,6));
}
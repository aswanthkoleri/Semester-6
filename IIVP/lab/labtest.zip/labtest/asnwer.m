C=rgb2gray(A);

C(C<225)=0;

s=strel('disk',4,0);%Structuring element

D=~im2bw(C);%binary Image

F=imerode(D,s);%Erode the image by structuring element


figure,imshow(A);title('Original Image');

figure,imshow(D);title('Binary Image');
`
Difference between binary image and Eroded image

figure,imshow(D-F);title('Boundary extracted Image');

A=imread('nutsbolts.tif');

s=strel('disk',2,0);

F=imerode(A,s);


figure,

subplot(2,1,1);

imshow(A);title('Binary Image');

subplot(2,1,2);

imshow(A-F);title('Boundary extracted Image');
%%
image = imread('img3.jpg');
temp=rgb2gray(image);
I=im2double(temp);
A = I > 0.3;
% A = imbinarize(I);
%  Adash  = bitcmp(A);
 subplot(1,3,1);
 imshow(A);
 title('Original')
%% A minus A erosion B 
B=[1 1 1 1 1 ;1 1 1 1 1 ; 1 1 1 1 1 ; 1 1 1 1 1 ; 1 1 1 1 1 ];
C=padarray(A,[0 1],1);
D=false(size(A));
for i=1:size(C,1)
    for j=1:size(C,2)-25
        L=C(i,j:j+25);
        K=find(B==1);
       if(L(K)==1)
        D(i,j)=1;
        end
    end
end
eroded= D;
subplot(1,3,2);
imshow(eroded);
title("A⊖b")
lhs = A-D(:,:);
subplot(1,3,3);
imshow(lhs);
title('A-(A⊖B)');
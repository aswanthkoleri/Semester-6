%%
image = imread('morphology.tif');
A=im2double(image)
% Adash  = bitcmp(A);
subplot(1,2,1);
imshow(A);
title('Original')
%% A minus A erosion B 
B=[1 1 1];
C=padarray(A,[0 1],1);
D=false(size(A));
for i=1:size(C,1)
    for j=1:size(C,2)-2
        L=C(i,j:j+2);

        K=find(B==1);
       if(L(K)==1)
        D(i,j)=1;
        end
    end
end
lhs = A-D(:,:);
subplot(1,2,2);
imshow(lhs);
title('A-(A⊖B)');



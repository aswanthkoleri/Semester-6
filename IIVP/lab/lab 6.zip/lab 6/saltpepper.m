%Read an image
i=imread('xyz.jpg');  
b=4;w=251;  
img_with_noise= i; 
[m,n]=size(i); 
x = randi([0,255],m,n);  
img_with_noise(x <= b) = 0;  
img_with_noise(x >=w) = 255;  

imshow(img_with_noise);

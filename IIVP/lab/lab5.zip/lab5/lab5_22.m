clear; clc;
I = imread('II.jpeg');
%I = imnoise(I, 'salt & pepper', 0.01);
subplot(2,1,1);
imshow(I),title('original');

m=3;
subplot(2,1,2);
img=myfunc(m,I);
imshow(img),title('vertial edge');

function img=myfunc(m,I)
    [r c] = size(I);
    Rep = zeros(r + m-1, c + m-1);
    for x = 2 : r + 1
        for y = 2 : c + 1
            Rep(x,y) = I(x - 1, y - 1);
        end
    end
    B = zeros(r, c);
    Filter = zeros(m);

    Filter(1,1)=-1;
    Filter(1,2)=0;
    Filter(1,3)=1;
    Filter(2,1)=-2;
    Filter(2,2)=0;
    Filter(2,3)=2;
    Filter(3,1)=-1;
    Filter(3,2)=0;
    Filter(3,3)=1;
    Filter=Filter/4;

    for x = 1 : r
        for y = 1 : c
            sum=0;
            for i = 1 : m
                for j = 1 : m
                    q = x - 1;
                    w = y -1;
                    mat=Rep(i + q, j + w);
                    k=mat*Filter(i,j);
                    sum=sum+k;
                    %sum=sum + m*res:
                end
            end
            B(x, y) = sum;
        end
    end
    
    img=uint8(B);
    %imshow(uint8(B)),title('gaussian');
end

%gaussian filtering
clear; clc;
I = imread('I.jpg');
%I = imnoise(I, 'salt & pepper', 0.01);
subplot(3,1,1);
imshow(I),title('original');

m=3;
subplot(3,1,2);
I1=myfunc(m,I,2);
I2=myfunc(m,I,1);
img1=I1-I2;
imshow(img1);

img2=myfunc1(m,I,2,1);
subplot(3,1,3);
imshow(img2);

function img=myfunc(m,I,sigma)
    [r c] = size(I);
    Rep = zeros(r + m-1, c + m-1);
    for x = 2 : r + 1
        for y = 2 : c + 1
            Rep(x,y) = I(x - 1, y - 1);
        end
    end
    B = zeros(r, c);
    Filter = zeros(m);

    for i=1:m
        for j=1:m
            res=gauss(i-(m-1)/2,j-(m-1)/2,sigma);
            Filter(i,j)=res;
        end
    end

    for x = 1 : r
        for y = 1 : c
            sum=0;
            for i = 1 : m
                for j = 1 : m
                    q = x - 1;
                    w = y -1;
                    mat=Rep(i + q, j + w);
                    k=mat*Filter(i,j);
                    sum=sum+k;
                    %sum=sum + m*res:
                end
            end
            B(x, y) = sum;
        end
    end
    img=uint8(B);
    %imshow(uint8(B)),title('gaussian');
end

function res = gauss(a,b,sigma)
    
    pwr=(a*a + b*b);
    pwr=pwr/(2* sigma*sigma);
    pwr=-pwr;
    res=exp(pwr);   
end

function img=myfunc1(m,I,sigma1,sigma2)
    [r c] = size(I);
    Rep = zeros(r + m-1, c + m-1);
    for x = 2 : r + 1
        for y = 2 : c + 1
            Rep(x,y) = I(x - 1, y - 1);
        end
    end
    B = zeros(r, c);
    Filter = zeros(m);

    for i=1:m
        for j=1:m
            res=gauss(i-(m-1)/2,j-(m-1)/2,sigma1)-gauss(i-(m-1)/2,j-(m-1)/2,sigma2);
            Filter(i,j)=res;
        end
    end

    for x = 1 : r
        for y = 1 : c
            sum=0;
            for i = 1 : m
                for j = 1 : m
                    q = x - 1;
                    w = y -1;
                    mat=Rep(i + q, j + w);
                    k=mat*Filter(i,j);
                    sum=sum+k;
                    %sum=sum + m*res:
                end
            end
            B(x, y) = sum;
        end
    end
    img=uint8(B);
    %imshow(uint8(B)),title('gaussian');
end
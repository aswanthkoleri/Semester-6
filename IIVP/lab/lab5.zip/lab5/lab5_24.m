clear; clc;
I = imread('II.jpeg');
[rows, columns, numberOfColorBands] = size(I);
if numberOfColorBands > 1
  I = I(:, :, 2); 
end
subplot(2, 1, 1);
imshow(I);
subplot(2, 1, 2);
F=fft2(I);
S=fftshift(log(1+abs(F)));
imshow(S,[]);
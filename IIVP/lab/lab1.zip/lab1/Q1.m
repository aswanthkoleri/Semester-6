I=imread('sample.png');
imshow(I);
imwrite(I,'new/image.png');
img=imread('sample.jpeg');
ans=bwconncomp(img);
disp(ans);
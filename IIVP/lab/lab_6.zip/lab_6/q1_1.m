
%loads the image and makes double precision representation for computations

A = imread('aaa.tif');

B = double(A);

[rows, columns] = size(B); %computes the dimensions of the image


%displays the original image with appropriate title

figure(1)

image(B);

colormap(gray(256));

axis('image');

title('Original image')


%makes a copy of the original image to be salted/peppered with noise

noisy_image = B;

noise_percent = 20;


for i = 1:rows %for loops iterate through every pixel

   for j = 1:columns
       noise_check = randi(noise_percent); %creates a random number between 1 and noise_percent
       if noise_check == noise_percent    %if the random number = noise_percent (1/noise_percent chance of any given pixel being noisy)
           noise_value = randi(256);    %creates a random noise value to replace the pixel
           noisy_image(i,j) = noise_value; %replaces the original pixel value with the random noise
       end
   end
end


%displays the noisy image with appropriate title

figure(2)

image(noisy_image);

colormap(gray(256));

axis('image');

title('Salt and pepper noise image')

idealfilter(X,P);

%IDEAL LOW-PASS FILTER
function idealfilter(~,P)
f=(noisy_image);
[M,N]=size(f);
F=fft2(double(f));
u=0:(M-1);
v=0:(N-1);
idx=find(u>M/2);
u(idx)=u(idx)-M;
idy=find(v>N/2);
v(idy)=v(idy)-N;
[V,U]=meshgrid(v,u);
D=sqrt(U.^2+V.^2);
H=double(D<=P);
G=H.*F;
g=real(ifft2(double(G)));
%imshow(f),figure,imshow(g,[ ]);
%end

%displays the ideal low pass filtered image with appropriate title

figure(3)

image(g);

colormap(gray(256));

axis('image');

title('filtered image')
end
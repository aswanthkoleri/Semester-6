clear; clc;
I = imread('abc.jpg');
I = imnoise(I, 'salt & pepper', 0.05);
subplot(2,1,1);
imshow(I),title('original with noise');

P=5;
subplot(2,1,2);
img=idealfilter(I,P);
imshow(img),title('FILTERED IMAGE');

%IDEAL LOW-PASS FILTER
function img=idealfilter(I,P)
f=(I);
[M,N]=size(f);
F=fft2(double(f));
u=0:(M-1);
v=0:(N-1);
idx=find(u>M/2);
u(idx)=u(idx)-M;
idy=find(v>N/2);
v(idy)=v(idy)-N;
[V,U]=meshgrid(v,u);
D=sqrt(U.^2+V.^2);
H=double(D<=P);
G=H.*F;
g=real(ifft2(double(G)));
img=uint8(g);
%imshow(f),figure,imshow(g,[ ]);
end